module.exports = {
  singleQuote: true,
  bracketSpacing: false,
  jsxBracketSameLine: true
};
