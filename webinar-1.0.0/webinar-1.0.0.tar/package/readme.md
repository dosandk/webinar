# Webinar materials

Browser API: DOM API, fetch, API, storages API, Web/Service Workers
